<?php

//Login data for the database. Use this file in all Models
$host = "127.0.0.1";
$user = "root";
$passwd = "";
$database = "coffeedb";
?>
