<!DOCTYPE html>
<html lang="rus">
<head>
  <title><?php echo $title;?></title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- <link href="../assets/css/main.css" rel="stylesheet"> -->
  <link href="../assets/css/style.css" rel="stylesheet">
  <meta property="og:image" content="/images/content-aware_spy2.JPG">
  <link rel="stylesheet" type="text/css" media="screen" href="../assets/css/slideshow.css">
</head>