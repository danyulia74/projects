<div class="menu">
  <a href="index.php" class="button">HOME</a>
  <a href="about.php" class="button">About us</a>
  <a href="coffe.php" class="button">Coffee</a>
  <a href="gallery.php" class="button">Our gallery</a>
  <a href="management.php" class="button">MANAGEMENT</a>
  </div>