<link rel="stylesheet" type="text/css" media="screen" href="css/main.css">

<footer class="footer">    
        <div class="bottom">
            <p class="address">Yulia's CoffeShop</p>
            <p class="phone">(613) 413-6726</p>
            <a href="https://www.facebook.com/yulia.danilova.39">Facebook</a>
            <p class="email">danyulia74@gmail.com</p>
            <p class="copyright">Copyright | 2019 | Yulia's CoffeShop</p>
        </div>
    </footer>
