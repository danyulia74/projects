<script src="../assets/js/slideshow.js"></script>
<?php 
$title = "Gallery";
include_once("../sections/header.php");
include_once("../sections/menu.php");
?>
<br>
<?php
?>

<div id="slideshow">
    <div id="prev"></div>
    <div id="next"></div>
</div>