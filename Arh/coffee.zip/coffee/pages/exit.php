<?php

setcookie("isLogin",'', time());
header('Location: ../index.php');