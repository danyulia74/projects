<link rel="stylesheet" type="text/css" media="screen" href="css/main.css">

<footer class="footer">    
        <div class="bottom">
            <p class="address">Heritage college</p>
            <p class="phone">(111) 111-2222</p>
            <a class="email" href="">HEART.CAKE.SHOP@GMAIL.COM</a>
            <p class="copyright">Copyright | 2019 | Heart Cake</p>
        </div>
    </footer>
д название кафе телефон +1(613)-413-6726  и ниже строка с адресом Ottawa, 111 Elgin St.