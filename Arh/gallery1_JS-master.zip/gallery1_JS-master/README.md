# gallery1_JS
On hover opacity changes, on click an image in the middle changes
