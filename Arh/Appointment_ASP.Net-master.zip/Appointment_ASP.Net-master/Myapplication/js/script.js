﻿function validateNumberJS(oSrc, args)
            {
    args.isValid = (args.Value % 5 == 0)
    
    if (args.isValid) {
        //console.log("valide");
    } else alert("This number is not valide");
    
    } 
